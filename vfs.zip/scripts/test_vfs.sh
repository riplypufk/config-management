cd "$(dirname "$0")/.."
python3.10 src/main.py --vfs "$1"